/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package animalcrossing;

/**
 *
 * @author jauga
 */
public class Driver
{
    public static void main(String[] args)
    {
        Start start = new Start();
        start.setVisible(true);
    }
}
